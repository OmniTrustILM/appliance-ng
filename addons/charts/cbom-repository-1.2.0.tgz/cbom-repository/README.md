# CBOM Repository - ILM

> This repository is part of the open-source project ILM. You can find more information about the project at [ILM](https://github.com/OmniTrustILM) repository, including the contribution guide.

This repository contains [Helm](https://helm.sh/) charts as part of the ILM platform.

## Prerequisites
- Kubernetes 1.19+
- Helm 3.8.0+

## Using this Chart

### Installation

**Add Helm chart repository**

**Create namespace**

We’ll need to define a Kubernetes namespace where the resources created by the Chart should be installed:
```bash
kubectl create namespace ilm
```

**Create `values.yaml`**

> **Note**
> You can also use `--set` options for the helm to apply configuration for the chart.

Copy the default `values.yaml` from the Helm chart and modify the values accordingly:
```bash
helm show values oci://hub.omnitrustregistry.com/ilm-helm/cbom-repository > values.yaml
```
Now edit the `values.yaml` according to your desired state, see [Configurable parameters](#configurable-parameters) for more information.

**Install**

For the basic installation, run:
```bash
helm install --namespace ilm -f values.yaml ilm-cbom-repository oci://hub.omnitrustregistry.com/ilm-helm/cbom-repository
```

**Save your configuration**

Always make sure you save the `values.yaml` and all `--set` and `--set-file` options you used. You will need to use the same options when you upgrade to new versions with Helm. In case you are changing the configuration, save the new configuration.

### Upgrade

> **Warning**
> Be sure that you always save your previous configuration!

For upgrading the installation, update your configuration and run:
```bash
helm upgrade --namespace ilm -f values.yaml ilm-cbom-repository oci://hub.omnitrustregistry.com/ilm-helm/cbom-repository
```

### Uninstall

You can use the `helm uninstall` command to uninstall the application:
```bash
helm uninstall --namespace ilm ilm-cbom-repository
```

## Configurable parameters

You can find current values in the [values.yaml](values.yaml).
You can also Specify each parameter using the `--set` or `--set-file` argument to `helm install`.

### Global parameters

Global values are used to define common parameters for the chart and all its sub-charts by exactly the same name.

| Parameter                         | Default value          | Description                                                           |
|-----------------------------------|------------------------|-----------------------------------------------------------------------|
| global.replicaCount               | `1`                    | Number of replicas for the application                                |
| global.image.registry             | `""`                   | Global docker registry name                                           |
| global.image.repository           | `""`                   | Global docker image repository name                                   |
| global.image.pullSecrets          | `[]`                   | Global array of secret names for image pull                           |
| global.trusted.certificates       | `""`                   | List of additional CA certificates that should be trusted             |
| global.httpProxy                  | `""`                   | Proxy to be used to access external resources through http            |
| global.httpsProxy                 | `""`                   | Proxy to be used to access external resources through https           |
| global.noProxy                    | `""`                   | Defines list of external resources that should not use proxy settings |
| global.initContainers             | `[]`                   | Global init containers                                                |
| global.sidecarContainers          | `[]`                   | Global sidecar containers                                             |
| global.additionalVolumes          | `[]`                   | Global additional volumes                                             |
| global.additionalVolumeMounts     | `[]`                   | Global additional volume mounts                                       |
| global.additionalPorts            | `[]`                   | Global additional ports                                               |
| global.additionalEnv.variables    | `[]`                   | Global additional environment variables                               |
| global.additionalEnv.secrets      | `[]`                   | Global additional environment secrets                                 |
| global.additionalEnv.configMaps   | `[]`                   | Global additional environment config maps                             |

### Local parameters

The following values may be configured:

| Parameter                                    | Default value               | Description                                                           |
|----------------------------------------------|-----------------------------|-----------------------------------------------------------------------|
| trusted.certificates                         | `""`                        | List of additional CA certificates that should be trusted             |
| httpProxy                                    | `""`                        | Proxy to be used to access external resources through http            |
| httpsProxy                                   | `""`                        | Proxy to be used to access external resources through https           |
| noProxy                                      | `""`                        | Defines list of external resources that should not use proxy settings |
| image.registry                               | `hub.omnitrustregistry.com` | Docker registry name for the image                                    |
| image.repository                             | `ilm`                       | Docker image repository name                                          |
| image.name                                   | `cbom-repository`           | Docker image name                                                     |
| image.tag                                    | `1.2.0`                     | Docker image tag                                                      |
| image.digest                                 | `""`                        | Docker image digest, will override tag if specified                   |
| image.pullPolicy                             | `IfNotPresent`              | Image pull policy                                                     |
| image.pullSecrets                            | `[]`                        | Array of secret names for image pull                                  |
| image.command                                | `[]`                        | Override the default command                                          |
| image.args                                   | `[]`                        | Override the default args                                             |
| image.securityContext.runAsNonRoot           | `true`                      | Run the container as non-root user                                    |
| image.securityContext.readOnlyRootFilesystem | `true`                      | Run the container with read-only root filesystem                      |
| image.resources                              | `{}`                        | The resources for the container                                       |
| podLabels                                    | `{}`                        | Labels to be added to the pod                                         |
| podAnnotations                               | `{}`                        | Annotations to be added to the pod                                    |
| podSecurityContext                           | `{}`                        | Pod security context                                                  |
| logging.level                                | `"INFO"`                    | Allowed values are `"INFO"`, `"DEBUG"`, `"WARN"`, `"TRACE"`           |
| service.type                                 | `"ClusterIP"`               | Type of the service that is exposed                                   |
| service.port                                 | `8080`                      | Port number of the exposed service                                    |
| cbomRepo.endpoint                            | `http://minio-service:9000` | Base endpoint for CBOM S3 storage                                     |
| cbomRepo.region                              | `eu-west-1`                 | Region for CBOM S3 storage                                            |
| cbomRepo.bucket                              | `cbom-repo`                 | Bucket name for CBOM S3 storage                                       |
| cbomRepo.usePathStyle                        | `true`                      | Use path style for S3 storage access                                  |
| cbomRepo.existingSecret                      | `""`                        | Existing Secret containing `access_key` and `secret_key`; skips generated CBOM credentials |
| cbomRepo.accessKey                           | `minioadmin`                | Access key for CBOM S3 storage                                        |
| cbomRepo.secretKey                           | `minioadmin`                | Secret key for CBOM S3 storage                                        |
| cbomRepo.corsAllowedOrigins                  | `""`                        | Origin of the ILM web console, e.g. `https://ilm.example.net` (§CORS) |
| minio.enabled                                | `false`                     | Enable/disable embedded MinIO server                                  |
| minio.existingSecret                          | `""`                        | Existing Secret containing the MinIO environment; skips generated MinIO credentials |

##### CORS (`cbomRepo.corsAllowedOrigins`)

Set this to the address operators type into their browser to reach the **ILM web
console** — scheme, host, and port if it is non-standard. No path, no trailing
slash. It is *not* the address of this service.

```yaml
# ILM console served at https://ilm.example.net
cbomRepo:
  corsAllowedOrigins: "https://ilm.example.net"
```

Several consoles go in one comma-separated list:

```yaml
  corsAllowedOrigins: "https://ilm.example.net,https://ilm-test.example.net"
```

The reason it is the console's address and not this one: the console's Settings
page health-checks the CBOM repository from the operator's browser, and a browser
only lets the page read the response if the page's own origin is listed here.
Leave it empty and that check fails with a CORS error, showing a warning beside
the configured URL even though the service is healthy.

Two related requirements:

- The `cbomRepositoryUrl` platform setting must resolve from that same browser
  *and* from ILM Core, which calls this service server-side. An in-cluster name
  such as `http://cbom-repository:8080` cannot be resolved by a browser, so the
  warning stays no matter what is configured here — publish the service under a
  name both can reach.
- This service has no authentication of its own, so every listed origin gets full
  read **and upload** access. `*` allows any origin and is for development only.

#### Existing credential Secrets

Create the referenced Secrets in the release namespace before starting the
workloads. The chart does not create or manage them:

```yaml
cbomRepo:
  existingSecret: cbom-s3-credentials
minio:
  enabled: true
  existingSecret: minio-environment
```

Use names different from `cbom-repository-secret` and `minio-secret`, respectively.
Reusing a generated name is rejected because Helm would otherwise delete the
previously chart-managed Secret when it disappears from the release manifest.

`cbomRepo.existingSecret` requires `access_key` and `secret_key`. Both the CBOM
container and the bucket initialization container use these keys.
`cbomRepo.accessKey` and `cbomRepo.secretKey` are ignored and may be omitted.

`minio.existingSecret` supplies the complete MinIO environment through `envFrom`.
It requires `MINIO_ROOT_USER` and `MINIO_ROOT_PASSWORD`. Include `MINIO_BROWSER`
with `on` or `off`; when using the console, also include
`MINIO_BROWSER_REDIRECT_URL`. These supplied settings replace the generated
browser settings; `minio.console.enabled` still controls the console port and
server argument. `minio.rootUser`, `minio.rootPassword` and
`minio.console.redirectUrl` are ignored. Disabling MinIO still omits all MinIO
resources and the bucket initialization container.

The two references are independent. An empty reference retains that component's
generated Secret and existing literal-value behavior. When using embedded
MinIO, ensure the CBOM credentials can access the configured bucket.

#### Customization parameters

| Parameter                | Default value | Description                        |
|--------------------------|---------------|------------------------------------|
| initContainers           | `[]`          | Init containers                    |
| sidecarContainers        | `[]`          | Sidecar containers                 |
| additionalVolumes        | `[]`          | Additional volumes                 |
| additionalVolumeMounts   | `[]`          | Additional volume mounts           |
| additionalPorts          | `[]`          | Additional ports                   |
| additionalEnv.variables  | `[]`          | Additional environment variables   |
| additionalEnv.secrets    | `[]`          | Additional environment secrets     |
| additionalEnv.configMaps | `[]`          | Additional environment config maps |

#### Probes parameters

For mode details about probes, see the [Kubernetes documentation](https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/).

| Parameter                                  | Default value | Description                                                                        |
|--------------------------------------------|---------------|------------------------------------------------------------------------------------|
| image.probes.liveness.enabled              | `false`       | Enable/disable liveness probe                                                      |
| image.probes.liveness.custom               | `{}`          | Custom liveness probe command. When defined, it will override the default command  |
| image.probes.liveness.initialDelaySeconds  | `20`          | Initial delay seconds for liveness probe                                           |
| image.probes.liveness.timeoutSeconds       | `5`           | Timeout seconds for liveness probe                                                 |
| image.probes.liveness.periodSeconds        | `10`          | Period seconds for liveness probe                                                  |
| image.probes.liveness.successThreshold     | `1`           | Success threshold for liveness probe                                               |
| image.probes.liveness.failureThreshold     | `3`           | Failure threshold for liveness probe                                               |
| image.probes.readiness.enabled             | `true`        | Enable/disable readiness probe                                                     |
| image.probes.readiness.custom              | `{}`          | Custom readiness probe command. When defined, it will override the default command |
| image.probes.readiness.initialDelaySeconds | `20`          | Initial delay seconds for readiness probe                                          |
| image.probes.readiness.timeoutSeconds      | `5`           | Timeout seconds for readiness probe                                                |
| image.probes.readiness.periodSeconds       | `10`          | Period seconds for readiness probe                                                 |
| image.probes.readiness.successThreshold    | `1`           | Success threshold for readiness probe                                              |
| image.probes.readiness.failureThreshold    | `3`           | Failure threshold for readiness probe                                              |
| image.probes.startup.enabled               | `true`        | Enable/disable startup probe                                                       |
| image.probes.startup.custom                | `{}`          | Custom startup probe command. When defined, it will override the default command   |
| image.probes.startup.initialDelaySeconds   | `15`          | Initial delay seconds for startup probe                                            |
| image.probes.startup.timeoutSeconds        | `5`           | Timeout seconds for startup probe                                                  |
| image.probes.startup.periodSeconds         | `10`          | Period seconds for startup probe                                                   |
| image.probes.startup.successThreshold      | `1`           | Success threshold for startup probe                                                |
| image.probes.startup.failureThreshold      | `45`          | Failure threshold for startup probe                                                |

### Additional parameters

Additional parameters may be found in the [values.yaml](values.yaml) and dependencies.
See dependent charts for the description of available parameters.
